import { Nav } from "@/components/marketing/nav";
import { Hero } from "@/components/marketing/hero";
import { MarketplaceShowcase } from "@/components/marketing/marketplace-showcase";
import { PlatformPreview } from "@/components/marketing/platform-preview";
import { CustomerSegments } from "@/components/marketing/customer-segments";
import { SupplierEcosystem } from "@/components/marketing/supplier-ecosystem";
import { InstallationServices } from "@/components/marketing/installation-services";
import { AnalyticsPreview } from "@/components/marketing/analytics-preview";
import { SecuritySection } from "@/components/marketing/security-section";
import { Testimonials } from "@/components/marketing/testimonials";
import { Pricing } from "@/components/marketing/pricing";
import { FinalCta } from "@/components/marketing/final-cta";
import { Footer } from "@/components/marketing/footer";

export default function MarketingPage() {
  return (
    <main className="relative min-h-screen bg-[#05050A] text-white antialiased">
      <Nav />
      <Hero />
      <MarketplaceShowcase />
      <PlatformPreview />
      <CustomerSegments />
      <SupplierEcosystem />
      <InstallationServices />
      <AnalyticsPreview />
      <SecuritySection />
      <Testimonials />
      <Pricing />
      <FinalCta />
      <Footer />
    </main>
  );
}
