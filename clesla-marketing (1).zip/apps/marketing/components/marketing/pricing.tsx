"use client";

import { Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { GlowCard } from "@/components/ui/glow-card";
import { SectionHeading } from "@/components/ui/section-heading";
import { cn } from "@/lib/utils";

const TIERS = [
  {
    name: "Starter",
    price: "$0",
    period: "/mo",
    desc: "For small dealers & retailers getting started",
    features: ["Marketplace access", "Up to 50 orders/mo", "Basic inventory tools", "Email support"],
    cta: "Get Started",
    highlight: false,
  },
  {
    name: "Growth",
    price: "$499",
    period: "/mo",
    desc: "For scaling suppliers & integrators",
    features: ["Everything in Starter", "RFQ procurement suite", "Multi-warehouse ERP", "Installation dispatch", "Priority support"],
    cta: "Start Growth Plan",
    highlight: true,
  },
  {
    name: "Enterprise",
    price: "Custom",
    period: "",
    desc: "For procurement teams & large networks",
    features: ["Everything in Growth", "Multi-tenant orgs & RBAC", "Dedicated supplier network", "Custom analytics & SLAs", "White-glove onboarding"],
    cta: "Contact Sales",
    highlight: false,
  },
];

export function Pricing() {
  return (
    <section id="pricing" className="border-t border-white/[0.06] py-24">
      <div className="mx-auto max-w-7xl px-6">
        <SectionHeading eyebrow="Pricing" title="Simple plans. Enterprise depth." />
        <div className="mt-14 grid grid-cols-1 gap-6 lg:grid-cols-3">
          {TIERS.map((tier, i) => (
            <GlowCard
              key={tier.name}
              delay={i * 0.06}
              className={cn(tier.highlight && "border-amber-400/30 bg-amber-400/[0.04]")}
            >
              {tier.highlight && (
                <span className="absolute right-4 top-4 rounded-full bg-amber-400 px-2.5 py-1 text-[10px] font-semibold text-black">
                  POPULAR
                </span>
              )}
              <p className="text-sm font-medium text-white/60">{tier.name}</p>
              <div className="mt-2 flex items-baseline gap-1">
                <span className="text-4xl font-semibold text-white">{tier.price}</span>
                <span className="text-sm text-white/40">{tier.period}</span>
              </div>
              <p className="mt-2 text-sm text-white/40">{tier.desc}</p>

              <ul className="mt-6 space-y-3">
                {tier.features.map((f) => (
                  <li key={f} className="flex items-start gap-2 text-sm text-white/70">
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-amber-300" />
                    {f}
                  </li>
                ))}
              </ul>

              <Button
                className={cn(
                  "mt-8 w-full",
                  tier.highlight
                    ? "bg-amber-400 text-black hover:bg-amber-300"
                    : "bg-white/[0.06] text-white hover:bg-white/[0.12]"
                )}
              >
                {tier.cta}
              </Button>
            </GlowCard>
          ))}
        </div>
      </div>
    </section>
  );
}
