"use client";

import { GlowCard } from "@/components/ui/glow-card";
import { SectionHeading } from "@/components/ui/section-heading";
import { ShieldCheck, Building2, FileSearch, Lock, Network } from "lucide-react";

const ITEMS = [
  { name: "Role-Based Access Control", icon: ShieldCheck, desc: "Granular permissions across teams" },
  { name: "Organizations", icon: Building2, desc: "Multi-org structures & hierarchies" },
  { name: "Audit Logs", icon: FileSearch, desc: "Full traceability on every action" },
  { name: "Data Encryption", icon: Lock, desc: "Encrypted at rest & in transit" },
  { name: "Multi-Tenant Architecture", icon: Network, desc: "Isolated, scalable, enterprise-ready" },
];

export function SecuritySection() {
  return (
    <section className="border-t border-white/[0.06] py-24">
      <div className="mx-auto max-w-7xl px-6">
        <SectionHeading eyebrow="Enterprise" title="Security built for procurement-grade trust" />
        <div className="mt-14 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-5">
          {ITEMS.map((item, i) => (
            <GlowCard key={item.name} delay={i * 0.04} className="text-center">
              <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-xl bg-amber-400/10 text-amber-300">
                <item.icon className="h-5 w-5" />
              </div>
              <p className="font-medium text-white">{item.name}</p>
              <p className="mt-1 text-xs text-white/40">{item.desc}</p>
            </GlowCard>
          ))}
        </div>
      </div>
    </section>
  );
}
