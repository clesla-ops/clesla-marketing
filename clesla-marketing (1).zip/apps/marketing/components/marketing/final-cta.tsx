"use client";

import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";

const PILLARS = ["Marketplace", "Procurement", "Suppliers", "Logistics", "Installations", "Analytics"];

export function FinalCta() {
  return (
    <section className="relative overflow-hidden border-t border-white/[0.06] py-28">
      <div className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute left-1/2 top-1/2 h-[500px] w-[800px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-amber-500/10 blur-[140px]" />
      </div>

      <div className="mx-auto max-w-4xl px-6 text-center">
        <motion.h2
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-3xl font-semibold tracking-tight sm:text-5xl"
        >
          Everything Your Audio &amp; Music Business Needs.
          <br />
          <span className="text-amber-300">One Platform.</span>
        </motion.h2>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.15 }}
          className="mt-8 flex flex-wrap items-center justify-center gap-3"
        >
          {PILLARS.map((p) => (
            <span key={p} className="rounded-full border border-white/10 bg-white/[0.03] px-4 py-1.5 text-sm text-white/60">
              {p}
            </span>
          ))}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.25 }}
          className="mt-10 flex flex-wrap items-center justify-center gap-4"
        >
          <Button size="lg" className="group bg-amber-400 text-black hover:bg-amber-300">
            Explore Marketplace
            <ArrowRight className="ml-1 h-4 w-4 transition-transform group-hover:translate-x-1" />
          </Button>
          <Button size="lg" variant="outline" className="border-white/15 bg-white/[0.02] text-white hover:bg-white/[0.08]">
            Request Demo
          </Button>
        </motion.div>
      </div>
    </section>
  );
}
