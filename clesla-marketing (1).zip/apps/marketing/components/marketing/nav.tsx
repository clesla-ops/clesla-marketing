"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";

const LINKS = [
  { label: "Marketplace", href: "#marketplace" },
  { label: "Solutions", href: "#solutions" },
  { label: "Churches", href: "#segments" },
  { label: "Schools", href: "#segments" },
  { label: "Studios", href: "#segments" },
  { label: "DJs", href: "#segments" },
  { label: "Suppliers", href: "#suppliers" },
  { label: "Installations", href: "#installations" },
  { label: "Pricing", href: "#pricing" },
];

export function Nav() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 w-full border-b border-white/[0.06] bg-[#05050A]/80 backdrop-blur-xl">
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
        <a href="/" className="flex items-center gap-2 text-lg font-semibold tracking-tight">
          <span className="inline-block h-2 w-2 rounded-full bg-amber-400" />
          Clesla
        </a>

        <ul className="hidden items-center gap-7 lg:flex">
          {LINKS.map((link) => (
            <li key={link.label}>
              <a
                href={link.href}
                className="text-sm text-white/60 transition-colors hover:text-white"
              >
                {link.label}
              </a>
            </li>
          ))}
        </ul>

        <div className="hidden items-center gap-3 lg:flex">
          <Button variant="ghost" className="text-white/70 hover:text-white hover:bg-white/[0.06]">
            Sign In
          </Button>
          <Button className="bg-amber-400 text-black hover:bg-amber-300">
            Request Demo
          </Button>
        </div>

        <button
          onClick={() => setOpen(!open)}
          className="text-white lg:hidden"
          aria-label="Toggle navigation"
        >
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </nav>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden border-t border-white/[0.06] bg-[#05050A] lg:hidden"
          >
            <div className="flex flex-col gap-4 px-6 py-6">
              {LINKS.map((link) => (
                <a key={link.label} href={link.href} className="text-sm text-white/70">
                  {link.label}
                </a>
              ))}
              <div className="mt-2 flex flex-col gap-2">
                <Button variant="ghost" className="text-white">Sign In</Button>
                <Button className="bg-amber-400 text-black hover:bg-amber-300">Request Demo</Button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
