const COLUMNS = [
  { title: "Platform", links: ["Marketplace", "Suppliers", "Installations", "Pricing"] },
  { title: "Resources", links: ["Documentation", "Company"] },
  { title: "Legal", links: ["Security", "Legal"] },
];

export function Footer() {
  return (
    <footer className="border-t border-white/[0.06] py-16">
      <div className="mx-auto max-w-7xl px-6">
        <div className="grid grid-cols-2 gap-10 sm:grid-cols-4">
          <div className="col-span-2 sm:col-span-1">
            <p className="flex items-center gap-2 text-lg font-semibold">
              <span className="inline-block h-2 w-2 rounded-full bg-amber-400" />
              Clesla
            </p>
            <p className="mt-3 text-sm text-white/40">
              The global operating system for audio &amp; music commerce.
            </p>
          </div>

          {COLUMNS.map((col) => (
            <div key={col.title}>
              <p className="text-sm font-medium text-white/70">{col.title}</p>
              <ul className="mt-4 space-y-2.5">
                {col.links.map((link) => (
                  <li key={link}>
                    <a href="#" className="text-sm text-white/40 hover:text-white">
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-white/[0.06] pt-6 text-xs text-white/30 sm:flex-row">
          <span>© {new Date().getFullYear()} Clesla, Inc. All rights reserved.</span>
          <span>Made for the global audio & music industry.</span>
        </div>
      </div>
    </footer>
  );
}
