"use client";

import { motion } from "framer-motion";
import { SectionHeading } from "@/components/ui/section-heading";
import { GlowCard } from "@/components/ui/glow-card";

const MODULES = [
  { name: "Marketplace", desc: "Browse & buy from verified vendors" },
  { name: "RFQ Procurement", desc: "Request quotes, compare bids" },
  { name: "Inventory ERP", desc: "Real-time multi-warehouse stock" },
  { name: "Supplier Network", desc: "1,800+ vetted partners" },
  { name: "Logistics", desc: "Freight, delivery, tracking" },
  { name: "Installations", desc: "Field service dispatch" },
  { name: "Analytics", desc: "Revenue & ops intelligence" },
  { name: "Billing", desc: "Invoicing, AR, payment terms" },
];

export function PlatformPreview() {
  return (
    <section id="solutions" className="border-t border-white/[0.06] py-24">
      <div className="mx-auto max-w-7xl px-6">
        <SectionHeading
          eyebrow="Platform"
          title="A live operating system, not a brochure"
          description="Every module connects — from quote to cash, supplier to install."
        />

        <div className="mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {MODULES.map((m, i) => (
            <GlowCard key={m.name} delay={i * 0.04}>
              <p className="font-medium text-white">{m.name}</p>
              <p className="mt-1 text-sm text-white/40">{m.desc}</p>
            </GlowCard>
          ))}
        </div>

        {/* Composite dashboard mock */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mt-10 grid gap-4 lg:grid-cols-3"
        >
          <div className="rounded-2xl border border-white/[0.08] bg-white/[0.02] p-5 lg:col-span-2">
            <p className="mb-4 text-sm font-medium text-white/70">Procurement Pipeline</p>
            <div className="space-y-3">
              {[
                { label: "RFQ Submitted", pct: 100 },
                { label: "Supplier Matching", pct: 85 },
                { label: "Quotes Received", pct: 64 },
                { label: "Order Confirmed", pct: 38 },
                { label: "Fulfilled", pct: 21 },
              ].map((s) => (
                <div key={s.label}>
                  <div className="mb-1 flex justify-between text-xs text-white/40">
                    <span>{s.label}</span>
                    <span>{s.pct}%</span>
                  </div>
                  <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/[0.06]">
                    <motion.div
                      initial={{ width: 0 }}
                      whileInView={{ width: `${s.pct}%` }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.8 }}
                      className="h-full rounded-full bg-amber-400"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="rounded-2xl border border-white/[0.08] bg-white/[0.02] p-5">
            <p className="mb-4 text-sm font-medium text-white/70">Supplier Performance</p>
            <table className="w-full text-left text-xs text-white/50">
              <thead>
                <tr className="border-b border-white/[0.06] text-white/30">
                  <th className="pb-2">Supplier</th>
                  <th className="pb-2">On-Time</th>
                  <th className="pb-2">Rating</th>
                </tr>
              </thead>
              <tbody>
                {[
                  ["Meridian Pro Audio", "98%", "4.9"],
                  ["NorthBeam Distribution", "94%", "4.7"],
                  ["StageWorks Mfg", "91%", "4.6"],
                  ["AudioForge Co.", "89%", "4.5"],
                ].map((row) => (
                  <tr key={row[0]} className="border-b border-white/[0.04]">
                    <td className="py-2 text-white/70">{row[0]}</td>
                    <td className="py-2">{row[1]}</td>
                    <td className="py-2">{row[2]}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
