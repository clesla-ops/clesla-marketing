"use client";

import { motion } from "framer-motion";
import { SectionHeading } from "@/components/ui/section-heading";
import { StatPill } from "@/components/ui/stat-pill";

export function AnalyticsPreview() {
  return (
    <section className="border-t border-white/[0.06] py-24">
      <div className="mx-auto max-w-7xl px-6">
        <SectionHeading
          eyebrow="Analytics"
          title="Operational intelligence, in real time"
          description="Revenue, procurement volume, supplier performance, and install metrics — unified."
        />

        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mt-14 rounded-2xl border border-white/[0.08] bg-white/[0.02] p-6"
        >
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
            <StatPill label="Revenue (MTD)" value="$4.2M" />
            <StatPill label="Orders" value="18,204" />
            <StatPill label="Inventory SKUs" value="92,300" />
            <StatPill label="Supplier Score" value="96.4" />
            <StatPill label="Procurement Vol." value="$1.8M" />
            <StatPill label="Installs Done" value="412" />
          </div>

          <div className="mt-6 grid gap-4 lg:grid-cols-3">
            <div className="rounded-xl border border-white/[0.06] bg-white/[0.02] p-4 lg:col-span-2">
              <p className="mb-3 text-xs uppercase tracking-wide text-white/40">Revenue vs Procurement Volume</p>
              <div className="flex h-40 items-end gap-3">
                {[60, 75, 50, 90, 65, 100, 80, 95].map((h, i) => (
                  <div key={i} className="flex flex-1 flex-col items-center gap-1">
                    <motion.div
                      initial={{ height: 0 }}
                      whileInView={{ height: `${h}%` }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.6, delay: i * 0.05 }}
                      className="w-full rounded-sm bg-amber-400/70"
                    />
                    <motion.div
                      initial={{ height: 0 }}
                      whileInView={{ height: `${h * 0.6}%` }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.6, delay: i * 0.05 + 0.1 }}
                      className="w-full rounded-sm bg-white/15"
                    />
                  </div>
                ))}
              </div>
            </div>
            <div className="rounded-xl border border-white/[0.06] bg-white/[0.02] p-4">
              <p className="mb-3 text-xs uppercase tracking-wide text-white/40">Installation Metrics</p>
              <ul className="space-y-3 text-sm text-white/60">
                <li className="flex justify-between"><span>Avg. completion</span><span className="text-white">4.2 days</span></li>
                <li className="flex justify-between"><span>On-time rate</span><span className="text-white">96%</span></li>
                <li className="flex justify-between"><span>CSAT</span><span className="text-white">4.8 / 5</span></li>
                <li className="flex justify-between"><span>Active crews</span><span className="text-white">214</span></li>
              </ul>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
