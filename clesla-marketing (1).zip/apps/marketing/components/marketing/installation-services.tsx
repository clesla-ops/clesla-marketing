"use client";

import { GlowCard } from "@/components/ui/glow-card";
import { SectionHeading } from "@/components/ui/section-heading";
import { Church, Disc3, Users, School, Music4, Tv } from "lucide-react";

const INSTALLS = [
  { name: "Church Audio Installations", icon: Church, meta: "1,200+ completed" },
  { name: "Studio Builds", icon: Disc3, meta: "340+ completed" },
  { name: "Conference Room AV", icon: Users, meta: "2,800+ completed" },
  { name: "School PA Systems", icon: School, meta: "960+ completed" },
  { name: "Concert Systems", icon: Music4, meta: "210+ completed" },
  { name: "Broadcast Facilities", icon: Tv, meta: "150+ completed" },
];

export function InstallationServices() {
  return (
    <section id="installations" className="border-t border-white/[0.06] py-24">
      <div className="mx-auto max-w-7xl px-6">
        <SectionHeading
          eyebrow="Installations"
          title="Field installs, dispatched like clockwork"
          description="Certified partners, scheduled and tracked end-to-end inside the platform."
        />
        <div className="mt-14 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {INSTALLS.map((item, i) => (
            <GlowCard key={item.name} delay={i * 0.04} className="aspect-[4/3] flex flex-col justify-between">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-amber-400/10 text-amber-300">
                <item.icon className="h-6 w-6" />
              </div>
              <div>
                <p className="text-lg font-medium text-white">{item.name}</p>
                <p className="mt-1 text-sm text-white/40">{item.meta}</p>
              </div>
            </GlowCard>
          ))}
        </div>
      </div>
    </section>
  );
}
