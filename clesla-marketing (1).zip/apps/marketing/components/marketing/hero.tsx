"use client";

import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ArrowRight, Play } from "lucide-react";
import { StatPill } from "@/components/ui/stat-pill";

export function Hero() {
  return (
    <section className="relative overflow-hidden pt-20 pb-24 sm:pt-28">
      {/* Ambient glow */}
      <div className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute left-1/2 top-0 h-[600px] w-[900px] -translate-x-1/2 rounded-full bg-amber-500/10 blur-[120px]" />
      </div>

      <div className="mx-auto max-w-7xl px-6 text-center">
        <motion.span
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="inline-block rounded-full border border-white/10 bg-white/[0.03] px-4 py-1.5 text-xs font-medium uppercase tracking-wider text-amber-300/80"
        >
          The Audio & Music Commerce OS
        </motion.span>

        <motion.h1
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="mx-auto mt-6 max-w-4xl text-4xl font-semibold leading-[1.1] tracking-tight sm:text-6xl"
        >
          The Global Operating System For{" "}
          <span className="bg-gradient-to-r from-amber-300 via-amber-100 to-white bg-clip-text text-transparent">
            Audio &amp; Music Commerce
          </span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="mx-auto mt-6 max-w-2xl text-base text-white/50 sm:text-lg"
        >
          Shop, source, procure, install, manage, and scale professional audio systems,
          musical instruments, and music technology — through one unified platform.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="mt-9 flex flex-wrap items-center justify-center gap-4"
        >
          <Button size="lg" className="group bg-amber-400 text-black hover:bg-amber-300">
            Explore Marketplace
            <ArrowRight className="ml-1 h-4 w-4 transition-transform group-hover:translate-x-1" />
          </Button>
          <Button size="lg" variant="outline" className="border-white/15 bg-white/[0.02] text-white hover:bg-white/[0.08]">
            <Play className="mr-1 h-4 w-4" />
            Request Demo
          </Button>
        </motion.div>

        {/* Animated SaaS interface preview */}
        <motion.div
          initial={{ opacity: 0, y: 40, scale: 0.97 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.45, ease: [0.16, 1, 0.3, 1] }}
          className="relative mx-auto mt-16 max-w-5xl"
        >
          <div className="overflow-hidden rounded-2xl border border-white/[0.08] bg-[#0A0A12] shadow-[0_0_0_1px_rgba(255,255,255,0.04),0_40px_120px_-40px_rgba(0,0,0,0.8)]">
            <div className="flex items-center gap-2 border-b border-white/[0.06] bg-white/[0.02] px-4 py-3">
              <div className="h-2.5 w-2.5 rounded-full bg-red-400/60" />
              <div className="h-2.5 w-2.5 rounded-full bg-amber-400/60" />
              <div className="h-2.5 w-2.5 rounded-full bg-emerald-400/60" />
              <span className="ml-3 text-xs text-white/40">app.clesla.com/dashboard</span>
            </div>

            <div className="grid grid-cols-1 gap-4 p-6 sm:grid-cols-4">
              <StatPill label="Open RFQs" value="128" />
              <StatPill label="Active Orders" value="3,402" />
              <StatPill label="Supplier Network" value="1,890" />
              <StatPill label="Installs in Progress" value="64" />

              <div className="col-span-full mt-2 grid gap-4 sm:grid-cols-3">
                <div className="rounded-xl border border-white/[0.06] bg-white/[0.02] p-4 sm:col-span-2">
                  <p className="mb-3 text-xs uppercase tracking-wide text-white/40">Revenue — Trailing 12mo</p>
                  <div className="flex h-32 items-end gap-2">
                    {[40, 55, 48, 62, 70, 58, 80, 74, 88, 95, 84, 100].map((h, i) => (
                      <motion.div
                        key={i}
                        initial={{ height: 0 }}
                        animate={{ height: `${h}%` }}
                        transition={{ duration: 0.6, delay: 0.6 + i * 0.04 }}
                        className="flex-1 rounded-sm bg-gradient-to-t from-amber-500/40 to-amber-300/80"
                      />
                    ))}
                  </div>
                </div>

                <div className="rounded-xl border border-white/[0.06] bg-white/[0.02] p-4">
                  <p className="mb-3 text-xs uppercase tracking-wide text-white/40">Live Activity</p>
                  <ul className="space-y-2 text-sm text-white/60">
                    <li>Order #48213 shipped</li>
                    <li>RFQ matched — 6 suppliers</li>
                    <li>Install scheduled — Dallas</li>
                    <li>Invoice #1182 paid</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
