"use client";

import { GlowCard } from "@/components/ui/glow-card";
import { SectionHeading } from "@/components/ui/section-heading";

const QUOTES = [
  {
    quote: "Clesla replaced four disconnected vendors with a single procurement workflow. Our install timelines dropped by 40%.",
    name: "Director of Operations",
    org: "Multi-Campus Church Network",
  },
  {
    quote: "We run RFQs across 60 suppliers in the time it used to take to call three.",
    name: "Head of Procurement",
    org: "State University System",
  },
  {
    quote: "Our distribution partners and install crews finally work off the same source of truth.",
    name: "VP of Supply Chain",
    org: "Pro Audio Manufacturer",
  },
];

export function Testimonials() {
  return (
    <section className="border-t border-white/[0.06] py-24">
      <div className="mx-auto max-w-7xl px-6">
        <SectionHeading eyebrow="Trusted at scale" title="What enterprise teams say" />
        <div className="mt-14 grid grid-cols-1 gap-4 lg:grid-cols-3">
          {QUOTES.map((t, i) => (
            <GlowCard key={t.name} delay={i * 0.08}>
              <p className="text-sm leading-relaxed text-white/70">&ldquo;{t.quote}&rdquo;</p>
              <div className="mt-5 border-t border-white/[0.06] pt-4">
                <p className="text-sm font-medium text-white">{t.name}</p>
                <p className="text-xs text-white/40">{t.org}</p>
              </div>
            </GlowCard>
          ))}
        </div>
      </div>
    </section>
  );
}
