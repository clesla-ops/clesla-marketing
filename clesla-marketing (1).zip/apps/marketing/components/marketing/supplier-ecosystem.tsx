"use client";

import { motion } from "framer-motion";
import { SectionHeading } from "@/components/ui/section-heading";

const NODES = [
  "Manufacturers", "Dealers", "Distributors",
  "Installation Partners", "Service Providers", "Logistics Partners",
];

export function SupplierEcosystem() {
  return (
    <section id="suppliers" className="border-t border-white/[0.06] py-24">
      <div className="mx-auto max-w-7xl px-6">
        <SectionHeading
          eyebrow="Network"
          title="A connected supplier ecosystem"
          description="Clesla unifies every partner type into one verified network graph."
        />

        <div className="relative mx-auto mt-16 flex h-[420px] max-w-3xl items-center justify-center">
          {/* Center node */}
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            whileInView={{ scale: 1, opacity: 1 }}
            viewport={{ once: true }}
            className="absolute z-10 flex h-24 w-24 items-center justify-center rounded-full border border-amber-300/30 bg-amber-400/10 text-sm font-semibold text-amber-200 shadow-[0_0_60px_-10px_rgba(251,191,36,0.5)]"
          >
            Clesla
          </motion.div>

          {NODES.map((node, i) => {
            const angle = (i / NODES.length) * 2 * Math.PI;
            const radius = 170;
            const x = Math.cos(angle) * radius;
            const y = Math.sin(angle) * radius;
            return (
              <motion.div
                key={node}
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
                style={{ transform: `translate(${x}px, ${y}px)` }}
                className="absolute flex h-28 w-28 flex-col items-center justify-center rounded-2xl border border-white/10 bg-white/[0.03] p-3 text-center text-xs text-white/70"
              >
                {node}
              </motion.div>
            );
          })}

          <svg className="pointer-events-none absolute inset-0 h-full w-full">
            {NODES.map((_, i) => {
              const angle = (i / NODES.length) * 2 * Math.PI;
              const radius = 170;
              const cx = 50 + (Math.cos(angle) * radius) / 7;
              const cy = 50 + (Math.sin(angle) * radius) / 7;
              return (
                <line
                  key={i}
                  x1="50%"
                  y1="50%"
                  x2={`${cx}%`}
                  y2={`${cy}%`}
                  stroke="rgba(251,191,36,0.15)"
                  strokeWidth="1"
                />
              );
            })}
          </svg>
        </div>
      </div>
    </section>
  );
}
