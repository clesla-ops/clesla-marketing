"use client";

import { GlowCard } from "@/components/ui/glow-card";
import { SectionHeading } from "@/components/ui/section-heading";
import {
  Church, School, GraduationCap, Disc3, Headphones,
  Factory, Truck, Warehouse, Store, Building2,
} from "lucide-react";

const SEGMENTS = [
  { name: "Churches", icon: Church, desc: "Worship-grade sound, installed & maintained" },
  { name: "Schools", icon: School, desc: "PA systems, classroom AV, procurement" },
  { name: "Universities", icon: GraduationCap, desc: "Campus-wide AV infrastructure" },
  { name: "Studios", icon: Disc3, desc: "Recording, mixing, mastering builds" },
  { name: "DJs", icon: Headphones, desc: "Mobile rigs, lighting, gear financing" },
  { name: "Manufacturers", icon: Factory, desc: "Sell direct, manage distribution" },
  { name: "Distributors", icon: Truck, desc: "Bulk logistics & dealer networks" },
  { name: "Wholesalers", icon: Warehouse, desc: "Inventory & B2B order management" },
  { name: "Retailers", icon: Store, desc: "Storefront + marketplace sync" },
  { name: "Enterprise Procurement", icon: Building2, desc: "RFQ workflows at scale" },
];

export function CustomerSegments() {
  return (
    <section id="segments" className="border-t border-white/[0.06] py-24">
      <div className="mx-auto max-w-7xl px-6">
        <SectionHeading
          eyebrow="Who it's for"
          title="Built for every player in the audio economy"
        />
        <div className="mt-14 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-5">
          {SEGMENTS.map((s, i) => (
            <GlowCard key={s.name} delay={i * 0.03} className="text-center">
              <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-xl bg-amber-400/10 text-amber-300">
                <s.icon className="h-5 w-5" />
              </div>
              <p className="font-medium text-white">{s.name}</p>
              <p className="mt-1 text-xs text-white/40">{s.desc}</p>
            </GlowCard>
          ))}
        </div>
      </div>
    </section>
  );
}
