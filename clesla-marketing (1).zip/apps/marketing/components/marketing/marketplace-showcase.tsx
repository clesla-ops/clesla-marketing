"use client";

import { GlowCard } from "@/components/ui/glow-card";
import { SectionHeading } from "@/components/ui/section-heading";
import {
  Speaker, Guitar, Mic, Sliders, Radio, Disc3, Headphones,
  Tv, Users, Church, School, Music4, Lightbulb, Package,
} from "lucide-react";

const CATEGORIES = [
  { name: "Professional Audio Systems", icon: Speaker, items: "12,400+ products" },
  { name: "Musical Instruments", icon: Guitar, items: "38,200+ products" },
  { name: "Microphones", icon: Mic, items: "6,100+ products" },
  { name: "Mixers", icon: Sliders, items: "3,800+ products" },
  { name: "Amplifiers", icon: Radio, items: "4,500+ products" },
  { name: "Studio Equipment", icon: Disc3, items: "9,300+ products" },
  { name: "DJ Equipment", icon: Headphones, items: "5,700+ products" },
  { name: "Broadcast Equipment", icon: Tv, items: "2,900+ products" },
  { name: "Conference Systems", icon: Users, items: "3,100+ products" },
  { name: "Church Audio Systems", icon: Church, items: "4,200+ products" },
  { name: "School Audio Systems", icon: School, items: "2,600+ products" },
  { name: "Stage Equipment", icon: Music4, items: "5,000+ products" },
  { name: "Lighting Equipment", icon: Lightbulb, items: "4,800+ products" },
  { name: "Accessories", icon: Package, items: "21,000+ products" },
];

export function MarketplaceShowcase() {
  return (
    <section id="marketplace" className="border-t border-white/[0.06] py-24">
      <div className="mx-auto max-w-7xl px-6">
        <SectionHeading
          eyebrow="Marketplace"
          title="One marketplace for every category in pro audio"
          description="Source from verified manufacturers, distributors, and dealers — with live pricing, MOQ tooling, and procurement workflows built in."
        />

        <div className="mt-14 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {CATEGORIES.map((cat, i) => (
            <GlowCard key={cat.name} delay={i * 0.03} className="flex items-center gap-4">
              <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-amber-400/10 text-amber-300">
                <cat.icon className="h-5 w-5" />
              </div>
              <div>
                <p className="font-medium text-white">{cat.name}</p>
                <p className="text-sm text-white/40">{cat.items}</p>
              </div>
            </GlowCard>
          ))}
        </div>
      </div>
    </section>
  );
}
