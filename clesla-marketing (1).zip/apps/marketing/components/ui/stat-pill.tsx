export function StatPill({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex flex-col gap-1 rounded-xl border border-white/[0.08] bg-white/[0.02] px-4 py-3">
      <span className="text-xs uppercase tracking-wide text-white/40">{label}</span>
      <span className="text-lg font-semibold text-white">{value}</span>
    </div>
  );
}
