# Clesla Marketing Frontend

This zip contains the frontend marketing experience for Clesla, scoped to:

```
apps/marketing/app/page.tsx
apps/marketing/components/marketing/*
apps/marketing/components/ui/*
```

## How to add this to your existing GitHub repo

1. **Download and unzip** this file (`clesla-marketing.zip`) anywhere on your machine.
2. **Copy the `apps` folder into the root of your repo**, merging with your existing `apps/marketing` directory if it already exists. On macOS/Linux from the unzipped folder:

   ```bash
   cp -R apps/marketing/app/*        /path/to/your-repo/apps/marketing/app/
   cp -R apps/marketing/components/* /path/to/your-repo/apps/marketing/components/
   ```

   Or just drag-and-drop the `apps/marketing` folder into your repo in Finder/Explorer, choosing "merge" if prompted.

3. **Confirm these already exist in your repo** (this drop does NOT include them, since you said not to touch config):
   - `apps/marketing/components/ui/button.tsx` (standard shadcn `Button`)
   - `apps/marketing/lib/utils.ts` exporting `cn()` (standard shadcn util)
   - `lucide-react`, `framer-motion` installed in `package.json`

   If any are missing, install/add via shadcn CLI rather than editing `package.json` by hand:
   ```bash
   npx shadcn@latest add button
   npm install framer-motion lucide-react
   ```

4. **Commit and push:**
   ```bash
   cd /path/to/your-repo
   git checkout -b feature/clesla-marketing-ui
   git add apps/marketing
   git commit -m "feat(marketing): add Clesla marketing frontend"
   git push origin feature/clesla-marketing-ui
   ```

5. Open a PR, or merge directly to `main` if you're working solo.

6. **Run locally to verify:**
   ```bash
   npm run dev
   ```
   Visit the marketing app's local URL and confirm `/` renders the full page (Nav → Hero → Marketplace → Platform → Segments → Suppliers → Installations → Analytics → Security → Testimonials → Pricing → Final CTA → Footer).

## Notes
- No `package.json`, `next.config.js`, auth, database, Stripe, API routes, middleware, or backend logic included or modified — this is pure presentational UI per your spec.
- All components are client components (`"use client"`) using Framer Motion for scroll/entry animations.
- Tailwind classes assume Tailwind v4 + shadcn defaults (dark background already set inline via `bg-[#05050A]`, no extra theme config required to preview).
